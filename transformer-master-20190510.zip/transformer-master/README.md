## A Pytorch Implementation of the Transformer Network
This repository includes pytorch implementations of ["Attention is All You Need"](https://papers.nips.cc/paper/7181-attention-is-all-you-need.pdf) (Vaswani et al., NIPS 2017) and 
["Weighted Transformer Network for Machine Translation"](https://arxiv.org/pdf/1711.02132.pdf) (Ahmed et al., arXiv 2017)
https://github.com/JayParks/transformer 

## Reference
**Paper**
- Vaswani et al., "Attention is All You Need", NIPS 2017
- Ahmed et al., "Weighted Transformer Network for Machine Translation", Arxiv 2017

**Code**
- [jadore801120/attention-is-all-you-need](https://github.com/jadore801120/attention-is-all-you-need-pytorch)
- [OpenNMT/OpenNMT-py](https://github.com/OpenNMT/OpenNMT-py)
- [The Annotated Transformers](http://nlp.seas.harvard.edu/2018/04/03/attention.html)

**train**
python3 preprocess.py -train_src ./data/multi30k/train.de -train_tgt ./data/multi30k/train.en -dev_src ./data/multi30k/val.de -dev_tgt ./data/multi30k/val.en -save_data multi30k-deen

python3 train.py -data_path ./deen-train.t7 -model_path deen-model 
**test**

