# !/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on 06 12  22:38 2018
Batch_attention_seq2seq_translation-pytorch/05-sequence-to-sequence/Batch_Attention_Seq2seq/attentionRNN.py
https://github.com/ChenZhongFu/Batch_attention_seq2seq_translation-pytorch/blob/master/05-sequence-to-sequence/Batch_Attention_Seq2seq/attentionRNN.py
@author: GLN
"""
import torch
from torch import nn
from torch.autograd import Variable
import torch.nn.functional as F
import math

class EncoderRNN(nn.Module):
    def __init__(self, input_size, embed_size, hidden_size, n_layers=1, dropout=0.):
        super(EncoderRNN, self).__init__()

        # Define parameters
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.embed_size = embed_size
        self.n_layers = n_layers
        self.dropout = dropout

        # Define layers
        self.embedding = nn.Embedding(input_size, embed_size)
        self.gru = nn.GRU(embed_size, hidden_size, n_layers, dropout=self.dropout, bidirectional=True)

    def forward(self, input_seqs, input_lengths, hidden=None):
        '''
        :param input_seqs: batch_size, T（batch_size个句子中最长的序列长度）
        :param input_lengths:
        :param hidden: initial state of GRU
        '''
        input_seqs = input_seqs.permute(1, 0)      # ==> T, batch_size
        embedded = self.embedding(input_seqs)      # ==> T, batch_size, emb_dim
        packed = torch.nn.utils.rnn.pack_padded_sequence(embedded, input_lengths.data.tolist())
        # 输入形状为:T, batch_size, emb_dim   ;
        # input_lengths.data.tolist()为每个序列的长度共有batch_size个
        # 返回值是一个packedSequence对象
        # packed[0].size()为[120=input_lengths.size()中每个句子长度的和, emb_dim=256]
        # packed[1].size() [seq_len=10] 其内容为：每个第i个元素代表batch中所有16个句子的第i个位置实际单词的个数
        outputs, hidden = self.gru(packed, hidden)
        outputs, output_lengths = torch.nn.utils.rnn.pad_packed_sequence(outputs)
        # outputs ==> T, batch_size, emb_dim * 2
        # output_lengths ==> batch中序列的长度列表
        outputs = outputs[:, :, :self.hidden_size] + outputs[:, :, self.hidden_size:]
        # outputs ==> T, batchsize, emb_dim
        return outputs, hidden

class Attn(nn.Module):
    def __init__(self, method, hidden_size):
        super(Attn, self).__init__()

        # Define parameters
        self.method = method
        self.hidden_size = hidden_size

        # Define layers
        if self.method == 'general':
            self.attn = nn.Linear(self.hidden_size, hidden_size)
            # input∗weight+bias
            # pytorch系列 ----暂时就叫5的番外吧： nn.Modlue及nn.Linear 源码理解
            # https://blog.csdn.net/dss_dssssd/article/details/82977170
        elif self.method == 'concat':
            self.attn = nn.Linear(self.hidden_size * 2, hidden_size)
            self.v = nn.Parameter(torch.rand(hidden_size))
            # self.v = [hidden_size=256]
            stdv = 1. / math.sqrt(self.v.size(0))
            # math.sqrt()的含义是开平方根 math.sqrt(self.v.size(0)=256)==>16
            # stdv = 1. / 16 ==> 0.0625
            self.v.data.normal_(mean=0., std=stdv)
            # 以上三行主要是用来对v这个参数进行参数的正态分布进行随机初始化
            # https://zhuanlan.zhihu.com/p/32103001
            # https://www.cnblogs.com/king-lps/p/8570021.html

    def score(self, hidden, encoder_outputs):
        if self.method == 'general':
            energy = self.attn(encoder_outputs)
            # batch_size, T, hidden_size ==> batch_size, T, hidden_size
            energy = torch.bmm(hidden, energy.permute(0, 2, 1))
            '''
            bmm ==> batch matrix multiply 下面是一个示例
            >>> batch1 = torch.randn(10, 3, 4)
            >>> batch2 = torch.randn(10, 4, 5)
            >>> res = torch.bmm(batch1, batch2)
            >>> res.size()
            torch.Size([10, 3, 5])
            '''
            # 在本例中 hidden [batch_size, 1, hidden_size], energy [batch_size, T, hidden_size]
            # bmm ==> [batch_size, 1, T]
        elif self.method == 'concat':
            energy = self.attn(torch.cat([hidden, encoder_outputs], 2)) # [B*T*2H]->[B*T*H]采用连接的方法
            # hidden = [batch_size, T, hidden_size]
            # encoder_outputs = [batch_size, T, hidden_size]
            # torch.cat([hidden, encoder_outputs], 2) ==> [batch_size, T, hidden_size * 2]
            # energy = [batch_size, T, hidden_size]
            energy = energy.transpose(2, 1)   # [B*H*T]
            # ==> energy [batch_size, hidden_size, T]
            v = self.v.repeat(encoder_outputs.data.shape[0], 1).unsqueeze(1) #[B*1*H]
            # self.v = [hidden_size=256] =(repeat)=> [batch_size, hidden_size]
            # =(unsqueeze(1))=> [batch_size, 1, hidden_size]
            energy = torch.bmm(v, energy) # [B*1*T]
            # v = [batch_size, 1, hidden_size]    energy = [batch_size, hidden_size, T]
            # ==> energy = [batch_size, 1, T]
        return energy.squeeze(1)    #[B*T]
        # energy.squeeze(1)  ==> [batch_size, T]

    def forward(self, hidden, encoder_outputs):
        '''
        :param hidden: batch_size, hidden_size
        :param encoder_outputs: T, batch_size, hidden_size
        '''
        max_len = encoder_outputs.size(0)                  # T
        this_batch_size = encoder_outputs.size(1)          # batch_size
        if self.method == 'general':
            H = hidden.unsqueeze(1)  #B,1,H
            # ==> batch_size, 1, hidden_size
            encoder_outputs = encoder_outputs.transpose(0, 1) #B,T,H
            # ==> batch_size, T, hidden_size
        elif self.method == 'concat':
            H = hidden.repeat(max_len, 1, 1).transpose(0, 1) #T,B,H->B,T,H
            # batch_size, hidden_size =(repeat)=> T, batch_size, hidden_size
            # T, batch_size, hidden_size =(transpose)=> batch_size, T, hidden_size
            encoder_outputs = encoder_outputs.transpose(0, 1) # [B,T,H]
            # ==> batch_size, T, hidden_size
        attn_energies = self.score(H, encoder_outputs) # compute attention score#B,T
        # attn_energies = [batch_size, T]

        return F.softmax(attn_energies).unsqueeze(1) # normalize with softmax#B,1,T
        # F.softmax(attn_energies).size() = [batch_size, T]
        # F.softmax(attn_energies).unsqueeze(1).size() = [batch_size, 1, T]

class AttnDecoderRNN(nn.Module):
    def __init__(self, hidden_size, embed_size, output_size, n_layers=1, dropout_p=0.1):
        super(AttnDecoderRNN, self).__init__()

        # Define parameters
        self.hidden_size = hidden_size
        self.embed_size = embed_size
        self.output_size = output_size   # 目标端的词典大小
        self.n_layers = n_layers
        self.dropout_p = dropout_p

        # Define layers
        self.embedding = nn.Embedding(output_size, embed_size)
        # 这里使用output_size的原因在于要将预测输出的y这个单词作为输入，得到它的embedding
        self.dropout = nn.Dropout(dropout_p)
        self.attn = Attn('concat', hidden_size)
        self.gru = nn.GRU(hidden_size + embed_size, hidden_size, n_layers, dropout=dropout_p, bidirectional=True)
        self.out = nn.Linear(hidden_size * 2, output_size)

    def forward(self, word_input, last_hidden, encoder_outputs):
        '''
        :param word_input: B, 1   batch_size, 1
        :param last_hidden:  layers * direction, B, H
        :param encoder_outputs: T, B, H
        '''
        word_embedded = self.embedding(word_input).view(1, word_input.size(0), -1) # (1,B,V)解码器输入单个
        # word_input = [batch_size, 1] ==> self.embedding(word_input) [batch_size, 1, emb_dim=256]
        # self.embedding(word_input).view(1, word_input.size(0), -1) [1, batch_size, emb_dim]
        word_embedded = self.dropout(word_embedded)
        # ==> [1, batch_size, emb_dim]

        # Calculate attention weights and apply to encoder outputs
        attn_weights = self.attn(last_hidden[0], encoder_outputs)    #B,1,T
        # last_hidden = [(layers=1 * direction=2)=2, batch_size, hidden_size]
        # last_hidden[0].size() = [batch_size, hidden_size]
        # encoder_outputs.size() = [T, batch_size, hidden_size]
        # attn_weights.size() = [batch_size, 1, T]
        context = attn_weights.bmm(encoder_outputs.transpose(0, 1))   # (B,1,H)
        # [batch_size, 1, T] bmm [batch_size, T, hidden_size] ==> [batch_size, 1, hidden_size]
        # context = [batch_size, 1, hidden_size]
        context = context.transpose(0, 1)
        # context = [1, batch_size, hidden_size]

        # Combine embedded input word and attended context, run through RNN
        rnn_input = torch.cat((word_embedded, context), 2)  #1,B,V+H
        # word_embedded = [1, batch_size, emb_dim] context = [1, batch_size, hidden_size]
        # rnn_input = [1, batch_size, emb_dim + hidden_size]
        output, hidden = self.gru(rnn_input, last_hidden)
        # rnn_input.size() = [seq_len=1, batch_size, input_size=emb_dim + hidden_size]
        # last_hidden.size() = [num_layers * num_directions, batch_size, hidden_size]
        # output.size() = [seq_len=1, batch_size, num_directions * hidden_size]
        # hidden.size() = [num_layers * num_directions, batch_size, hidden_size]
        output = output.squeeze(0)  # (1,B,H*2)->(B,H*2)
        # ==> [batch_size, num_directions * hidden_size]
        output = F.log_softmax(self.out(output))  #B,V
        # self.out(output).size() = [batch_size, output_size]
        # F.log_softmax(self.out(output)).size() = [batch_size, output_size]

        # Return final output, hidden state
        return output, hidden

    def my_batch_nllloss(self, input, target):
        # input.size() = [batch_size, output_size]
        # target.size() = [batch_size, 1]
        batch_loss = -torch.gather(input, 1, target)
        # batch_loss.size() = [batch_size, 1]
        # 1.pytorch中一些常用方法的总结
        # 1.https://blog.csdn.net/ANNILingMo/article/details/78006227

        # 2.利用pytorch中的gather函数取出矩阵中的元素
        # 2.https://blog.csdn.net/qq_32492561/article/details/80113180
        return batch_loss























