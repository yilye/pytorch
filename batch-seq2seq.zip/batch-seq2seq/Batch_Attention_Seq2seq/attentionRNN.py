# !/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on 04 12  23:06 2018
Batch_attention_seq2seq_translation-pytorch/05-sequence-to-sequence/Batch_Attention_Seq2seq/attentionRNN.py
https://github.com/ChenZhongFu/Batch_attention_seq2seq_translation-pytorch/blob/master/05-sequence-to-sequence/Batch_Attention_Seq2seq/attentionRNN.py
@author: GLN
"""

import torch
from torch import nn
from torch.autograd import Variable
import torch.nn.functional as F
import math

class EncoderRNN(nn.Module):
    def __init__(self, input_size, embed_size, hidden_size, n_layers=1, dropout=0.):
        super(EncoderRNN, self).__init__()

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.embed_size = embed_size
        self.n_layers = n_layers
        self.dropout = dropout

        self.embedding = nn.Embedding(input_size, embed_size)
        self.gru = nn.GRU(embed_size, hidden_size, n_layers, dropout=self.dropout, bidirectional=True)

    def forward(self, input_seqs, input_lengths, hidden=None):
        '''
        input_seqs: B,T
        hidden: initial state of GRU
        '''
        # input_seqs [batch_size=16, seq_len=10]
        input_seqs=input_seqs.permute(1,0)
        # input_seqs [seq_len=10, batch_size=16]
        embedded = self.embedding(input_seqs)#T,B,H
        # embedded [seq_len=10, batch_size=16, emb_dim=256]
        packed = torch.nn.utils.rnn.pack_padded_sequence(embedded, input_lengths.data.tolist())
        # input_lengths.size() = [batch_size=16] 每个元素代表每条句子的实际长度，从大到小排列
        # packed ==> batch_sizes=10 每个第i个元素代表batch中所有16个句子的第i个位置实际单词的个数
        # packed[0].size() [120=input_lengths.size()中每个句子长度的和, emb_dim=256]
        # packed[1].size() [seq_len=10] 其内容为：每个第i个元素代表batch中所有16个句子的第i个位置实际单词的个数
        outputs, hidden = self.gru(packed, hidden)
        # hidden.size() [2, batch_size=16, hidden_size=256]
        # outputs ==> batch_sizes=10 每个第i个元素代表batch中所有16个句子的第i个位置实际单词的个数
        # outputs[0].size() [120=input_lengths.size()中每个句子长度的和, hidden_size * 2 =512]
        # outputs[1].size() [seq_len=10] 其内容为：每个第i个元素代表batch中所有16个句子的第i个位置实际单词的个数

        outputs, output_lengths = torch.nn.utils.rnn.pad_packed_sequence(outputs)
        #
        #


        outputs = outputs[:, :, :self.hidden_size] + outputs[:, :, self.hidden_size:]  # T,B,H
        return outputs, hidden

'''
input_seqs.size():
torch.Size([10, 16])

input_seqs:
[ 222	7	26	156	26	7	7	7	7	26	26	7	136	156	222	  131]	16	
[ 257	12	27	27	27	12	12	257	12	27	27	8	139	27	223	  226]	16	
[ 223	56	1031	313	54	16	725	4	1534	57	1031	2230	1564	313	932	  134]	16	
[ 258	245	128	1180	1705	112	113	2746	113	113	128	260	380	1735	71	 3520]	16	
[ 260	1679	531	245	7	245	1435	258	255	1435	3043	81	1565	801	72	    6]	16	
[ 313	449	16	261	12	2229	4243	711	1467	1023	6	6	6	6	6	    2]	16	
[ 205	485	4241	3764	144	35	6	6	6	6	2	2	2	2	2	    0]	15	
[1969	3319	6	6	6	6	2	2	2	2	0	0	0	0	0	    0]	10	
[   6	6	2	2	2	2	0	0	0	0	0	0	0	0	0	    0]	6	
[   2	2	0	0	0	0	0	0	0	0	0	0	0	0	0	    0]	2	
10	10	9	9	9	9	8	8	8	8	7	7	7	7	7	6		129
																129	

embedded.size():
torch.Size([10, 16, 256])

input_lengths:
[10, 10,  9,  9,  9,  9,  8,  8,  8,  8,  7,  7,  7,  7,  7,  6]

packed[0].size():
torch.Size([129, 256])

packed[1].size():
torch.Size([10])
packed[1]:   [16, 16, 16, 16, 16, 16, 15, 10,  6,  2]

hidden.size():
torch.Size([2, 16, 256])

outputs[0].size():
torch.Size([129, 512])

outputs[1].size():
torch.Size([10])

outputs[1]
[16, 16, 16, 16, 16, 16, 15, 10,  6,  2]
之前
outputs, output_lengths = torch.nn.utils.rnn.pad_packed_sequence(outputs)
之后
output_lengths
[10, 10,  9,  9,  9,  9,  8,  8,  8,  8,  7,  7,  7,  7,  7,  6]

outputs.size()
torch.Size([10, 16, 512])
之前
outputs = outputs[:, :, :self.hidden_size] + outputs[:, :, self.hidden_size:]  # T,B,H
之后
outputs.size()
torch.Size([10, 16, 256])
'''






