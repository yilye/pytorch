# !/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on 05 12  23:38 2018
Batch_attention_seq2seq_translation-pytorch/05-sequence-to-sequence/train_batch_attention_seq2seq.py
https://github.com/ChenZhongFu/Batch_attention_seq2seq_translation-pytorch/blob/master/05-sequence-to-sequence/train_batch_attention_seq2seq.py
@author: GLN
"""

import os
import numpy as np
import torch
from torch import optim
from torch.autograd import Variable
from torch.utils.data import DataLoader

from utils.dataset import TextDataset
from Batch_Attention_Seq2seq.attentionRNN import EncoderRNN, AttnDecoderRNN

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
use_cuda = torch.cuda.is_available()

SOS_token = 1
EOS_token = 2
MAX_LENGTH = 10
lang_dataset = TextDataset()
lang_dataloader = DataLoader(lang_dataset, batch_size=16, shuffle=True)

in_len_dic = lang_dataset.input_lang_words
out_len_dic = lang_dataset.output_lang_words

emb_dim = 256
hidden_size = 256
num_epoches = 50
batch_size = 16

if use_cuda:
    encoderModel = EncoderRNN(in_len_dic, emb_dim, hidden_size).cuda()
    attentionDecoderModel = AttnDecoderRNN(hidden_size, emb_dim, out_len_dic).cuda()
else:
    encoderModel = EncoderRNN(in_len_dic, emb_dim, hidden_size)
    attentionDecoderModel = AttnDecoderRNN(hidden_size, emb_dim, out_len_dic)

param = list(encoderModel.parameters()) + list(attentionDecoderModel.parameters())

optimizer = optim.Adam(param, lr=1e-3)

for epoch in range(num_epoches):
    train_loss = 0
    train_acc = 0
    for i, data in enumerate(lang_dataloader):
        x, y, mask = data
        if use_cuda:
            x = Variable(x).cuda()
            y = Variable(y).cuda()
            mask = Variable(mask).cuda()
        else:
            x = Variable(x)
            y = Variable(y)
            mask = Variable(mask)
        # 处理输入，使其按非0序列长度降序排序
        sort_value, sort_index = torch.sort(torch.sum(x != 0, 1), descending=True)
        # torch.sum(x != 0, 1)将所有不等于0的值的个数在维度1方向求和
        # 这里需要注意，当x!=0时，计算的是对应维度的个数，当只有x时，计算的是对应维度各个元素之和
        # torch.sort()按照降序对torch.sum(x!=0, 1)进行排序
        # sort_value为从大到小排列的batch中16个句子的长度
        # sort_index为batch降序排序的原始位置标记
        x = x[sort_index]
        y = y[sort_index]
        mask = mask[sort_index]
        # 将x, y, mask 按照排序好的位置进行排列从大到小降序

        encoder_outputs, encoder_hidden = encoderModel(x, sort_value)
        # encoder_hidden.size() [2, batch_size=16, emb_dim=256]
        # encoder_outputs.size() torch.Size([seq_len=9, batch_size=16, emb_dim=256])
        decoder_input = Variable(torch.LongTensor([[SOS_token] * len(y)])).view(-1, 1)
        # decoder_input.size() [16, 1]
        # decoder_input的形式如下：
        # tensor([[1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1]])
        if use_cuda:
            decoder_input = decoder_input.cuda()
        decoder_hidden = encoder_hidden
        #
        loss = 0
        acc_t = 0
        mask_end = Variable(torch.ByteTensor([1] * len(y)).view(-1, 1))  # 结束开关
        # torch.ByteTensor([1]*len(y)) ==> tensor([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], dtype=torch.uint8)
        # torch.ByteTensor([1] * len(y)).view(-1, 1)如下：
        # tensor([[1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1],
        #         [1]], dtype=torch.uint8)

        if use_cuda:
            mask_end = mask_end.cuda()
        mask_length = 0
        for di in range(y.size(1)):
            y_ = y[:, di].contiguous().view(-1, 1)  # B,1
            # y：
            # tensor([[  16,   45,  318,  512,  411,    5,    2,    0,    0,    0],
            #         [ 135,   85,  806,  950,   39,  950,    7,    5,    2,    0],
            #         [   3,    4,   68,  563, 2205,  135,   47, 2589,    5,    2],
            #         [ 135,   85,  153,   47, 1052,    5,    2,    0,    0,    0],
            #         [   3,    4, 1428, 1264,  135,    5,    2,    0,    0,    0],
            #         [   3,    4,  950,   39,  950,  135,    5,    2,    0,    0],
            #         [   3,   18,   30,  563,  603,  135,    5,    2,    0,    0],
            #         [ 135,   85,   47, 1211,  249,    5,    2,    0,    0,    0],
            #         [   3,    4,  562,    5,    2,    0,    0,    0,    0,    0],
            #         [ 135,   85,  151,  364,    5,    2,    0,    0,    0,    0],
            #         [ 135,   85,  325, 1225,    5,    2,    0,    0,    0,    0],
            #         [ 135,   85,  157, 1047,    5,    2,    0,    0,    0,    0],
            #         [ 135,   85,  325,  129,    5,    2,    0,    0,    0,    0],
            #         [   3,    4,  848,  105,    5,    2,    0,    0,    0,    0],
            #         [  84,   85,  552,   49,    5,    2,    0,    0,    0,    0],
            #         [   3,    4,   47,  253,    5,    2,    0,    0,    0,    0]],
            # y[:,di] ==> [ 16, 135,   3, 135,   3,   3,   3, 135,   3, 135, 135, 135, 135, 3, 84, 3]
            # 此处y[:,di]对应y的所有行的第di列的值
            # contiguous：view只能用在contiguous的variable上。
            # 如果在view之前用了transpose, permute等，需要用contiguous()来返回一个contiguous copy。
            # 一种可能的解释是：
            # 有些tensor并不是占用一整块内存，而是由不同的数据块组成，而tensor的view()操作依赖于内存是整块的，
            # 这时只需要执行contiguous()这个函数，把tensor变成在内存中连续分布的形式。
            # y[:,di].contiguous().view(-1,1)
            # tensor([[ 16],
            #         [135],
            #         [  3],
            #         [135],
            #         [  3],
            #         [  3],
            #         [  3],
            #         [135],
            #         [  3],
            #         [135],
            #         [135],
            #         [135],
            #         [135],
            #         [  3],
            #         [ 84],
            #         [  3]], device='cuda:0')

            mask_ = mask[:, di].contiguous().view(-1, 1)  # B,1
            # mask：
            # tensor([[1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
            #         [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
            #         [1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            #         [1, 1, 1, 1, 1, 1, 0, 0, 0, 0]]
            # mask[:, di] ==> tensor([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],

            mask_ = mask_ * mask_end
            # mask_*mask_end
            # tensor([[1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1],
            #         [1]], device='cuda:0', dtype=torch.uint8)

            decoder_output, decoder_hidden = attentionDecoderModel(decoder_input, decoder_hidden, encoder_outputs)
            # encoder_outputs.size() ==> torch.Size([9, 16, 256])
            # decoder_hidden.size() ==> torch.Size([2, 16, 256])
            # decoder_input.size() ==> torch.Size([16, 1])
            # decoder_output.size() ==> torch.Size([16, 3117])
            # loss_not_mask=criterion(decoder_output, y[:, di])#未mask损失
            loss_not_mask = attentionDecoderModel.my_batch_nllloss(decoder_output, y_)  # 未mask损失#B,1
            # loss_not_mask.size() ==> torch.Size([16, 1])

            mask_length += mask_
            loss_mask = loss_not_mask * mask_.float()
            loss += loss_mask
            max_value, max_index = torch.max(decoder_output, 1)  # 取最大可能的一个,B
            # max_value.size() ==> torch.Size([16])
            # max_index.size() ==> torch.Size([16])


            ni = max_index.view(-1, 1)  # b,1
            # max_index ==> tensor([1808,  700,   16,  656,   16,  656,  656, 1135,  896,  556, 1135,  656, 656,   16, 1530, 2387]
            # max_index.view(-1, 1)如下：
            # tensor([[1808],
            #         [ 700],
            #         [  16],
            #         [ 656],
            #         [  16],
            #         [ 656],
            #         [ 656],
            #         [1135],
            #         [ 896],
            #         [ 556],
            #         [1135],
            #         [ 656],
            #         [ 656],
            #         [  16],
            #         [1530],
            #         [2387]], device='cuda:0')

            # 若预测为结束标签，则其后的mask全置为0
            mask_end[ni == EOS_token] = 0

            # 准确次数
            # 注意此时mask_，TOT
            if (mask_ == 0).data.sum() == len(mask_):
                break
            y_pre = torch.masked_select(ni, mask_)
            # y_pre ==> [1808,  700,   16,  656,   16,  656,  656, 1135,  896,  556, 1135,  656, 656,   16, 1530, 2387]

            y_true = torch.masked_select(y_, mask_)
            # y_true ==> [ 16, 135, 3, 135, 3, 3, 3, 135, 3, 135, 135, 135, 135, 3,84, 3]

            acc_t += (y_pre == y_true).data.sum()  # 加上每个序列的batch准确次数

            decoder_input = ni  # 前面的输出作为后面的输入

        loss = torch.sum(loss) / len(y)
        # backward
        optimzier.zero_grad()
        loss.backward()
        optimzier.step()
        train_loss += loss.data[0]
        train_acc += acc_t / mask_length.data.sum()
        if (i + 1) % 100 == 0:
            print('[{}/{}],train loss is:{:.6f},train acc is:{:.6f}'.format(i, len(lang_dataloader),
                                                                            train_loss / (i + 1),
                                                                            train_acc / (i + 1)))
    print(
        'epoch:[{}],train loss is:{:.6f},train acc is:{:.6f}'.format(epoch,
                                                                     train_loss / (len(lang_dataloader)),
                                                                     train_acc / (len(lang_dataloader))))

torch.save(encoderModel.state_dict(), './model/encoder_model.pth')
torch.save(attentionDecoderModel.state_dict(), './model/decoder_model.pth')


